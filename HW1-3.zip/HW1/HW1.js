/* 
Quyen Dong
w899090
CSC440
HW1

Assignment: Write Javascript functions that will transform a given 
string into various forms as shown in the attached figure. 
The function names are in bold face in the figure.
*/

//Prompts user & gets input
/*var prompt = require('prompt');
prompt.start('Please enter a string.');
prompt.get(['string'], function (err, result)
{
	console.log('You entered: ' + result.string);
	let string = result.string;
	console.log(string);
});
var rl = require('readline-sync');
var response = '';
response = rl.question("Enter a string.");
console.log(response);
*/

console.log("This program runs a string and outputs in one of the following casings:");
console.log("Here are your options: ");
console.log("1. camelCase->    changeFormatToThis");
console.log("2. snakeCase->    change_format_to_this");
console.log("3. dashCase/kebabCase-> change-format-to-this");
console.log("4. dotCase->      change.format.to.this");
console.log("5. pathCase->     change/format/to/this");
console.log("6. properCase/pascalCase-> ChangeFormatToThis");
console.log("7. lowerCase->    change format to this");
console.log("8. sentenceCase-> Change format to this");
console.log("9. constantCase-> CHANGE_FORMAT_TO_THIS");
console.log("10. titleCase->   Change Format To This");
console.log("One must edit the script to enter a new string or different choice of casing.");
console.log("Please enter the number beside the option you want.\n");

let string = 'Enter String Here';
console.log('You entered: ', string);


let choice = '1';
console.log('Choice: ', choice);

if (choice <= 0 | choice >= 10)
{
	console.log('Please enter a valid choice. Exiting program.');
}

//Gets choice
switch (choice)
{
	case '1': //camelCase
		{ 
			console.log("You have chosen camelCase.");
			string = string.toLowerCase();
			string = string.trimRight();
			let i = string.length;
			splitstring = string.split(' '); //string is split into parts named splitstring[0], 								splitstring[1], etc.
			let o = splitstring.length;	//i indicates how many indexes there are in the array
			let splitchar = '';
			let endslice = '';
			for (k = 1; k < o; k++)
			{	
				splitchar = splitstring[k].charAt(0); //character at 0 in that index = splitchar
				splitchar = splitchar.toUpperCase(); //splitchar is changed to uppercase
				endslice = splitstring[k].slice(1); //endslice = the index split at character 1 								    of that array
				splitstring[k] = splitchar + endslice; 
			}			
			string = splitstring.join('');
			console.log(string);
			break; //done
		}
	case '2': //snakeCase
		{
			console.log("You have chosen snakeCase.");
			let i = / +/g;
			string = string.toLowerCase();
			string = string.trimRight();
			string = string.replace(i, '_');
			console.log(string);
			break;	//done
		}
	case '3': //dashCase
		{
			console.log("You have chosen dashCase/kebabCase.");
			let i = / +/g;
			string = string.toLowerCase();
			string = string.trimRight();
			string = string = string.replace(i, '-');
			console.log(string);
			break;	//done
		}
	case '4': //dotCase
		{
			console.log("You have chosen dotCase.");
			let i = / +/g;
			string = string.toLowerCase();
			string = string.trimRight();
			string = string = string.replace(i, '.');
			console.log(string);
			break;	//done
		}	
	case '5': //pathCase
		{
			console.log("You have chosen pathCase.");
			let i = / +/g;
			string = string.toLowerCase();
			string = string.trimRight();
			string = string = string.replace(i, '/');
			console.log(string);
			break;	//done
		}
	case '6': //properCase/pascalCase
		{
			console.log("You have chosen properCase/pascalCase.");
			string = string.toLowerCase();
			string = string.trimRight();
			splitstring = string.split(' '); //string is split into parts named splitstring[0], 								splitstring[1], etc.
			let i = splitstring.length;	//i indicates how many indexes there are in the array
			let splitchar = '';
			let endslice = '';
			for (k = 0; k < i; k++)
			{	
				splitchar = splitstring[k].charAt(0); //character at 0 in that index = splitchar
				splitchar = splitchar.toUpperCase(); //splitchar is changed to uppercase
				endslice = splitstring[k].slice(1); //endslice = the index split at character 1 								    of that array
				splitstring[k] = splitchar + endslice; 
			}			
			string = splitstring.join('');
			console.log(string);
			break;	//done
		}
	case '7': //lowerCase
		{
			console.log("You have chosen lowerCase.");
			string = string.toLowerCase();
			console.log(string);
			break;	//done
		}
	case '8': //sentenceCase
		{
			console.log("You have chosen sentenceCase.");
			string = string.toLowerCase();
			let i = string.length;
			let char = string.charAt(0);
			char = char.toUpperCase();
			let sstring = string.slice(1);
			string = char + sstring;
			console.log(string);
			break; //done
		}
	case '9': //constantCase
		{
			console.log("You have chosen constantCase.");
			string = string.toUpperCase();
			let i = / +/g;
			string = string.replace(i, '_');
			console.log(string);
			break; //done
		}
	case '10': //titleCase
		{
			console.log("You have chosen titleCase.");
			string = string.toLowerCase();
			string = string.trimRight();
			splitstring = string.split(' '); //string is split into parts named splitstring[0], 								splitstring[1], etc.
			let i = splitstring.length;	//i indicates how many indexes there are in the array
			let splitchar = '';
			let endslice = '';
			for (k = 0; k < i; k++)
			{	
				splitchar = splitstring[k].charAt(0); //character at 0 in that index = splitchar
				splitchar = splitchar.toUpperCase(); //splitchar is changed to uppercase
				endslice = splitstring[k].slice(1); //endslice = the index split at character 1 								    of that array
				splitstring[k] = splitchar + endslice; 
			}			
			string = splitstring.join(' ')	;
			console.log(string);
			break; //done
		}
};
